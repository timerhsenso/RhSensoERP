using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using RhSensoERP.Infrastructure.Persistence;
using RhSensoERP.Infrastructure.Persistence.Interceptors;
using RhSensoERP.Core.Security.Entities;
using Xunit;
using FluentAssertions;

namespace RhSensoERP.Tests.Unit.Infrastructure;

/// <summary>
/// Testes de conectividade e mapeamento do banco de dados
/// Verifica se o EF Core consegue acessar as tabelas legacy
/// </summary>
public class DatabaseConnectionTests : IDisposable
{
    private readonly AppDbContext _context;

    public DatabaseConnectionTests()
    {
        // Configura contexto para testes (usa banco real)
        var services = new ServiceCollection();
        services.AddHttpContextAccessor();
        services.AddScoped<AuditSaveChangesInterceptor>();

        // IMPORTANTE: Usar connection string do banco real para estes testes
        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer("Server=localhost;Database=bd_rhu_copenor;Trusted_Connection=true;TrustServerCertificate=true;")
                   .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

        var serviceProvider = services.BuildServiceProvider();
        _context = serviceProvider.GetRequiredService<AppDbContext>();
    }

    [Fact]
    public async Task Should_Connect_To_Database()
    {
        // Act & Assert
        var canConnect = await _context.Database.CanConnectAsync();
        canConnect.Should().BeTrue("deve conseguir conectar ao banco bd_rhu_copenor");
    }

    [Fact]
    public async Task Should_Read_Users_From_tuse1()
    {
        // Act
        var users = await _context.Users.Take(5).ToListAsync();

        // Assert
        users.Should().NotBeNull("deve conseguir ler tabela tuse1");
        // Não falha se não houver usuários (tabela pode estar vazia)
    }

    [Fact]
    public async Task Should_Read_Sistemas_From_tsistema()
    {
        // Act
        var sistemas = await _context.Sistemas.Take(5).ToListAsync();

        // Assert
        sistemas.Should().NotBeNull("deve conseguir ler tabela tsistema");
        // Se houver sistemas, verifica estrutura
        if (sistemas.Any())
        {
            var primeiro = sistemas.First();
            primeiro.CdSistema.Should().NotBeNullOrEmpty();
            primeiro.DcSistema.Should().NotBeNullOrEmpty();
        }
    }

    [Fact]
    public async Task Should_Read_Funcoes_From_fucn1()
    {
        // Act
        var funcoes = await _context.Funcoes.Take(5).ToListAsync();

        // Assert
        funcoes.Should().NotBeNull("deve conseguir ler tabela fucn1");
        if (funcoes.Any())
        {
            var primeira = funcoes.First();
            primeira.CdFuncao.Should().NotBeNullOrEmpty();
            primeira.CdSistema.Should().NotBeNullOrEmpty();
        }
    }

    [Fact]
    public async Task Should_Read_BotoesFuncao_From_btfuncao()
    {
        // Act
        var botoes = await _context.BotoesFuncao.Take(5).ToListAsync();

        // Assert
        botoes.Should().NotBeNull("deve conseguir ler tabela btfuncao");
        if (botoes.Any())
        {
            var primeiro = botoes.First();
            primeiro.NmBotao.Should().NotBeNullOrEmpty();
            primeiro.CdAcao.Should().BeOneOf('I', 'A', 'E', 'C');
        }
    }

    [Fact]
    public async Task Should_Read_UserGroups_From_usrh1()
    {
        // Act
        var userGroups = await _context.UserGroups.Take(5).ToListAsync();

        // Assert
        userGroups.Should().NotBeNull("deve conseguir ler tabela usrh1");
        if (userGroups.Any())
        {
            var primeiro = userGroups.First();
            primeiro.CdUsuario.Should().NotBeNullOrEmpty();
            primeiro.CdGrUser.Should().NotBeNullOrEmpty();
            primeiro.DtIniVal.Should().NotBe(default(DateTime));
        }
    }

    [Fact]
    public async Task Should_Read_GruposDeUsuario_From_gurh1()
    {
        // Act
        var grupos = await _context.GruposDeUsuario.Take(5).ToListAsync();

        // Assert
        grupos.Should().NotBeNull("deve conseguir ler tabela gurh1");
        if (grupos.Any())
        {
            var primeiro = grupos.First();
            primeiro.CdGrUser.Should().NotBeNullOrEmpty();
            primeiro.CdSistema.Should().NotBeNullOrEmpty();
        }
    }

    [Fact]
    public async Task Should_Read_GruposFuncoes_From_hbrh1()
    {
        // Act
        var grupoFuncoes = await _context.GruposFuncoes.Take(5).ToListAsync();

        // Assert
        grupoFuncoes.Should().NotBeNull("deve conseguir ler tabela hbrh1");
        if (grupoFuncoes.Any())
        {
            var primeiro = grupoFuncoes.First();
            primeiro.CdGrUser.Should().NotBeNullOrEmpty();
            primeiro.CdFuncao.Should().NotBeNullOrEmpty();
            primeiro.CdAcoes.Should().NotBeNullOrEmpty();
        }
    }

    public void Dispose()
    {
        _context?.Dispose();
    }
}