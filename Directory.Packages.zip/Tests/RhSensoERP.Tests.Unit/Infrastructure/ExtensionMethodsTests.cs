using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using RhSensoERP.Infrastructure.Persistence;
using RhSensoERP.Infrastructure.Persistence.Interceptors;
using RhSensoERP.Core.Security.Entities;
using Xunit;
using FluentAssertions;

namespace RhSensoERP.Tests.Unit.Infrastructure;

/// <summary>
/// Testes dos métodos de extensão criados para facilitar queries
/// </summary>
public class ExtensionMethodsTests : IDisposable
{
    private readonly AppDbContext _context;

    public ExtensionMethodsTests()
    {
        var services = new ServiceCollection();
        services.AddHttpContextAccessor();
        services.AddScoped<AuditSaveChangesInterceptor>();

        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer("Server=localhost;Database=bd_rhu_copenor;Trusted_Connection=true;TrustServerCertificate=true;"));

        var serviceProvider = services.BuildServiceProvider();
        _context = serviceProvider.GetRequiredService<AppDbContext>();
    }

    [Fact]
    public async Task Ativos_Should_Filter_Active_Users()
    {
        // Act
        var usuariosAtivos = await _context.Users.Ativos().ToListAsync();

        // Assert
        usuariosAtivos.Should().NotBeNull();
        usuariosAtivos.Should().OnlyContain(u => u.FlAtivo == 'S', "deve retornar apenas usuários ativos");
    }

    [Fact]
    public async Task Ativos_Should_Filter_Active_Sistemas()
    {
        // Act
        var sistemasAtivos = await _context.Sistemas.Ativos().ToListAsync();

        // Assert
        sistemasAtivos.Should().NotBeNull();
        sistemasAtivos.Should().OnlyContain(s => s.Ativo == true, "deve retornar apenas sistemas ativos");
    }

    [Fact]
    public async Task AtivosDoUsuario_Should_Filter_Active_Groups()
    {
        // Arrange
        var primeiroUser = await _context.UserGroups.Select(ug => ug.CdUsuario).FirstOrDefaultAsync();

        if (primeiroUser != null)
        {
            // Act
            var gruposAtivos = await _context.UserGroups.AtivosDoUsuario(primeiroUser).ToListAsync();

            // Assert
            gruposAtivos.Should().NotBeNull();
            gruposAtivos.Should().OnlyContain(ug => ug.DtFimVal == null, "deve retornar apenas grupos sem data fim");
            gruposAtivos.Should().OnlyContain(ug => ug.CdUsuario == primeiroUser, "deve filtrar pelo usuário correto");
        }
    }

    public void Dispose()
    {
        _context?.Dispose();
    }
}
