using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using RhSensoERP.Infrastructure.Persistence;
using RhSensoERP.Infrastructure.Persistence.Interceptors;
using RhSensoERP.Core.Security.Entities;
using Xunit;
using FluentAssertions;

namespace RhSensoERP.Tests.Unit.Infrastructure;

/// <summary>
/// Testes de relacionamentos entre entidades
/// Verifica se as FKs e navegação estão funcionando
/// </summary>
public class EntityRelationshipTests : IDisposable
{
    private readonly AppDbContext _context;

    public EntityRelationshipTests()
    {
        var services = new ServiceCollection();
        services.AddHttpContextAccessor();
        services.AddScoped<AuditSaveChangesInterceptor>();

        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer("Server=localhost;Database=bd_rhu_copenor;Trusted_Connection=true;TrustServerCertificate=true;"));

        var serviceProvider = services.BuildServiceProvider();
        _context = serviceProvider.GetRequiredService<AppDbContext>();
    }

    [Fact]
    public async Task Should_Load_Sistema_With_Funcoes()
    {
        // Arrange & Act
        var sistemaComFuncoes = await _context.Sistemas
            .Include(s => s.Funcoes)
            .FirstOrDefaultAsync();

        // Assert
        if (sistemaComFuncoes != null)
        {
            sistemaComFuncoes.Funcoes.Should().NotBeNull("relacionamento Sistema -> Funcoes deve funcionar");
        }
    }

    [Fact]
    public async Task Should_Load_Funcao_With_Sistema()
    {
        // Arrange & Act
        var funcaoComSistema = await _context.Funcoes
            .Include(f => f.Sistema)
            .FirstOrDefaultAsync();

        // Assert
        if (funcaoComSistema != null)
        {
            funcaoComSistema.Sistema.Should().NotBeNull("relacionamento Funcao -> Sistema deve funcionar");
            funcaoComSistema.Sistema.CdSistema.Should().Be(funcaoComSistema.CdSistema);
        }
    }

    [Fact]
    public async Task Should_Load_Funcao_With_Botoes()
    {
        // Arrange & Act
        var funcaoComBotoes = await _context.Funcoes
            .Include(f => f.Botoes)
            .FirstOrDefaultAsync();

        // Assert
        if (funcaoComBotoes != null)
        {
            funcaoComBotoes.Botoes.Should().NotBeNull("relacionamento Funcao -> Botoes deve funcionar");
        }
    }

    [Fact]
    public async Task Should_Load_UserGroup_With_User()
    {
        // Arrange & Act
        var userGroupComUser = await _context.UserGroups
            .Include(ug => ug.User)
            .FirstOrDefaultAsync(ug => ug.IdUsuario != null);

        // Assert
        if (userGroupComUser != null)
        {
            userGroupComUser.User.Should().NotBeNull("relacionamento UserGroup -> User deve funcionar");
        }
    }

    public void Dispose()
    {
        _context?.Dispose();
    }
}