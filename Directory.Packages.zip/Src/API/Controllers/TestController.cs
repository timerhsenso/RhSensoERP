using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RhSensoERP.Infrastructure.Persistence;
using RhSensoERP.Core.Shared;

namespace RhSensoERP.API.Controllers;

/// <summary>
/// Controller para testes de conectividade e mapeamento
/// Use apenas em desenvolvimento para verificar se está tudo funcionando
/// REMOVER EM PRODUÇÃO!
/// </summary>
[ApiController]
[Route("api/v1/test")]
[Produces("application/json")]
public class TestController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly ILogger<TestController> _logger;

    public TestController(AppDbContext context, ILogger<TestController> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Testa conectividade com o banco de dados
    /// </summary>
    [HttpGet("database-connection")]
    public async Task<ActionResult<ApiResponse<object>>> TestDatabaseConnection()
    {
        try
        {
            var canConnect = await _context.Database.CanConnectAsync();
            
            if (!canConnect)
            {
                return BadRequest(ApiResponse<object>.Fail("Não foi possível conectar ao banco de dados"));
            }

            var result = new
            {
                Connected = true,
                DatabaseName = _context.Database.GetDbConnection().Database,
                ServerVersion = await GetServerVersion()
            };

            return Ok(ApiResponse<object>.Ok(result, "Conexão com banco estabelecida com sucesso"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao testar conexão com banco");
            return StatusCode(500, ApiResponse<object>.Fail($"Erro interno: {ex.Message}"));
        }
    }

    /// <summary>
    /// Testa leitura de todas as tabelas mapeadas
    /// </summary>
    [HttpGet("table-mappings")]
    public async Task<ActionResult<ApiResponse<object>>> TestTableMappings()
    {
        try
        {
            var result = new
            {
                Users = await _context.Users.CountAsync(),
                Sistemas = await _context.Sistemas.CountAsync(),
                Funcoes = await _context.Funcoes.CountAsync(),
                BotoesFuncao = await _context.BotoesFuncao.CountAsync(),
                UserGroups = await _context.UserGroups.CountAsync(),
                GruposDeUsuario = await _context.GruposDeUsuario.CountAsync(),
                GruposFuncoes = await _context.GruposFuncoes.CountAsync()
            };

            return Ok(ApiResponse<object>.Ok(result, "Todas as tabelas acessadas com sucesso"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao acessar tabelas");
            return StatusCode(500, ApiResponse<object>.Fail($"Erro ao acessar tabelas: {ex.Message}"));
        }
    }

    /// <summary>
    /// Testa relacionamentos entre entidades
    /// </summary>
    [HttpGet("relationships")]
    public async Task<ActionResult<ApiResponse<object>>> TestRelationships()
    {
        try
        {
            // Testa relacionamento Sistema -> Funcoes
            var sistemaComFuncoes = await _context.Sistemas
                .Include(s => s.Funcoes)
                .Take(1)
                .FirstOrDefaultAsync();

            // Testa relacionamento Funcao -> Botoes
            var funcaoComBotoes = await _context.Funcoes
                .Include(f => f.Botoes)
                .Take(1)
                .FirstOrDefaultAsync();

            // Testa relacionamento UserGroup -> User
            var userGroupComUser = await _context.UserGroups
                .Include(ug => ug.User)
                .Where(ug => ug.IdUsuario != null)
                .Take(1)
                .FirstOrDefaultAsync();

            var result = new
            {
                SistemaComFuncoes = sistemaComFuncoes != null ? new
                {
                    Sistema = sistemaComFuncoes.CdSistema,
                    QuantidadeFuncoes = sistemaComFuncoes.Funcoes.Count
                } : null,
                
                FuncaoComBotoes = funcaoComBotoes != null ? new
                {
                    Funcao = funcaoComBotoes.CdFuncao,
                    QuantidadeBotoes = funcaoComBotoes.Botoes.Count
                } : null,
                
                UserGroupComUser = userGroupComUser != null ? new
                {
                    Usuario = userGroupComUser.User?.CdUsuario,
                    Grupo = userGroupComUser.CdGrUser
                } : null
            };

            return Ok(ApiResponse<object>.Ok(result, "Relacionamentos testados com sucesso"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao testar relacionamentos");
            return StatusCode(500, ApiResponse<object>.Fail($"Erro nos relacionamentos: {ex.Message}"));
        }
    }

    /// <summary>
    /// Testa métodos de extensão
    /// </summary>
    [HttpGet("extensions")]
    public async Task<ActionResult<ApiResponse<object>>> TestExtensions()
    {
        try
        {
            var result = new
            {
                UsuariosAtivos = await _context.Users.Ativos().CountAsync(),
                SistemasAtivos = await _context.Sistemas.Ativos().CountAsync(),
                TotalUsuarios = await _context.Users.CountAsync(),
                TotalSistemas = await _context.Sistemas.CountAsync()
            };

            return Ok(ApiResponse<object>.Ok(result, "Métodos de extensão funcionando"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Erro ao testar extensões");
            return StatusCode(500, ApiResponse<object>.Fail($"Erro nas extensões: {ex.Message}"));
        }
    }

    /// <summary>
    /// Teste completo - executa todos os testes
    /// </summary>
    [HttpGet("full")]
    public async Task<ActionResult<ApiResponse<object>>> FullTest()
    {
        try
        {
            var startTime = DateTime.UtcNow;

            // 1. Conectividade
            var canConnect = await _context.Database.CanConnectAsync();
            if (!canConnect) throw new Exception("Falha na conexão");

            // 2. Contagem de registros
            var counts = new
            {
                Users = await _context.Users.CountAsync(),
                Sistemas = await _context.Sistemas.CountAsync(),
                Funcoes = await _context.Funcoes.CountAsync(),
                BotoesFuncao = await _context.BotoesFuncao.CountAsync(),
                UserGroups = await _context.UserGroups.CountAsync(),
                GruposDeUsuario = await _context.GruposDeUsuario.CountAsync(),
                GruposFuncoes = await _context.GruposFuncoes.CountAsync()
            };

            // 3. Teste de query complexa
            var usuarioComGrupos = await _context.Users
                .Include(u => u.UserGroups)
                .FirstOrDefaultAsync();

            var duration = DateTime.UtcNow - startTime;

            var result = new
            {
                Status = "SUCCESS",
                Duration = $"{duration.TotalMilliseconds}ms",
                DatabaseConnection = true,
                TableCounts = counts,
                SampleData = usuarioComGrupos != null ? new
                {
                    Usuario = usuarioComGrupos.CdUsuario,
                    Nome = usuarioComGrupos.DcUsuario,
                    QuantidadeGrupos = usuarioComGrupos.UserGroups.Count
                } : null
            };

            return Ok(ApiResponse<object>.Ok(result, "Todos os testes passaram com sucesso! 🎉"));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Falha no teste completo");
            return StatusCode(500, ApiResponse<object>.Fail($"Teste falhou: {ex.Message}"));
        }
    }

    private async Task<string> GetServerVersion()
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();
            
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT @@VERSION";
            var result = await command.ExecuteScalarAsync();
            return result?.ToString()?.Split('\n')[0] ?? "Unknown";
        }
        catch
        {
            return "Unknown";
        }
    }
}
