// =============================================================================
// RHSENSOERP WEB - USER PERMISSIONS CACHE SERVICE INTERFACE
// =============================================================================
// Arquivo: src/Web/Services/Permissions/IUserPermissionsCacheService.cs
// Descri��o: Interface para cache de permiss�es do usu�rio
// =============================================================================

using RhSensoERP.Web.Models.Account;

namespace RhSensoERP.Web.Services.Permissions;

/// <summary>
/// Service para gerenciamento de cache de permiss�es do usu�rio.
/// Usa IMemoryCache internamente e IAuthApiService como fallback.
/// </summary>
public interface IUserPermissionsCacheService
{
    /// <summary>
    /// Armazena permiss�es do usu�rio no cache.
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    /// <param name="permissions">ViewModel com as permiss�es</param>
    /// <param name="expiration">Tempo de expira��o (default: 8 horas)</param>
    void Set(string cdUsuario, UserPermissionsViewModel permissions, TimeSpan? expiration = null);

    /// <summary>
    /// Obt�m permiss�es do cache (sem fallback para API).
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    /// <returns>Permiss�es ou null se n�o estiver em cache</returns>
    UserPermissionsViewModel? Get(string cdUsuario);

    /// <summary>
    /// Obt�m permiss�es do cache ou busca na API se n�o existir.
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Permiss�es do usu�rio</returns>
    Task<UserPermissionsViewModel?> GetOrFetchAsync(string cdUsuario, CancellationToken ct = default);

    /// <summary>
    /// Obt�m as a��es permitidas (IAEC) para uma fun��o espec�fica.
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    /// <param name="cdFuncao">C�digo da fun��o (ex: "RHU_FM_TAUX1")</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>String com a��es permitidas (ex: "IAC" = Include, Alter, Consult)</returns>
    Task<string> GetPermissionsForFunctionAsync(string cdUsuario, string cdFuncao, CancellationToken ct = default);

    /// <summary>
    /// Verifica se o usu�rio tem permiss�o para uma a��o espec�fica em uma fun��o.
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    /// <param name="cdFuncao">C�digo da fun��o (ex: "RHU_FM_TAUX1")</param>
    /// <param name="acao">A��o: 'I' (Include), 'A' (Alter), 'E' (Exclude), 'C' (Consult)</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>true se o usu�rio tem a permiss�o</returns>
    Task<bool> HasPermissionAsync(string cdUsuario, string cdFuncao, char acao, CancellationToken ct = default);

    /// <summary>
    /// Remove permiss�es do cache para um usu�rio.
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    void Remove(string cdUsuario);

    /// <summary>
    /// Atualiza (refresh) as permiss�es do usu�rio no cache.
    /// Remove o cache existente e busca novamente na API.
    /// </summary>
    /// <param name="cdUsuario">C�digo do usu�rio</param>
    /// <param name="ct">Cancellation token</param>
    /// <returns>Permiss�es atualizadas</returns>
    Task<UserPermissionsViewModel?> RefreshAsync(string cdUsuario, CancellationToken ct = default);
}