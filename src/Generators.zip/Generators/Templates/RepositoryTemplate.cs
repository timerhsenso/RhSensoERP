// =============================================================================
// RHSENSOERP GENERATOR v4.8 - REPOSITORY TEMPLATE
// =============================================================================
// Arquivo: src/Generators/Templates/RepositoryTemplate.cs
// v4.8: FIX - Removido EntityState.Modified no UpdateAsync.
//       Entidade já é tracked (buscada pelo Handler sem AsNoTracking).
//       EntityState.Modified forçava UPDATE em TODAS as colunas (inclusive PK),
//       causando erro no SQL Server para PK composta e Id auto-gerado.
// v4.7: ADICIONADO - Suporte a chave primária composta
// =============================================================================
using RhSensoERP.Generators.Models;

namespace RhSensoERP.Generators.Templates;

/// <summary>
/// Template para geração de Repository (Interface + Implementação).
/// </summary>
public static class RepositoryTemplate
{
    /// <summary>
    /// Gera a Interface do Repository.
    /// </summary>
    public static string GenerateInterface(EntityInfo info)
    {
        var entityNs = $"{info.BaseNamespace}.Core.Entities";

        // ✅ v4.7: Usa helpers para PK composta
        var getByIdParams = info.PrimaryKeyParameterList;
        var existsParams = info.PrimaryKeyParameterList;

        return $$"""
{{info.FileHeader}}
using {{entityNs}};

namespace {{info.RepositoryInterfaceNamespace}};

using System;
using System.Collections.Generic;

/// <summary>
/// Interface do repositório de {{info.DisplayName}}.
/// </summary>
public interface I{{info.EntityName}}Repository
{
    /// <summary>
    /// Retorna um IQueryable para consultas customizadas.
    /// </summary>
    IQueryable<{{info.EntityName}}> Query();

    /// <summary>
    /// Busca por ID.
    /// </summary>
    Task<{{info.EntityName}}?> GetByIdAsync({{getByIdParams}}, CancellationToken ct = default);

    /// <summary>
    /// Busca todos os registros.
    /// </summary>
    Task<IEnumerable<{{info.EntityName}}>> GetAllAsync(CancellationToken ct = default);

    /// <summary>
    /// Adiciona um novo registro.
    /// </summary>
    Task AddAsync({{info.EntityName}} entity, CancellationToken ct = default);

    /// <summary>
    /// Atualiza um registro existente.
    /// </summary>
    Task UpdateAsync({{info.EntityName}} entity, CancellationToken ct = default);

    /// <summary>
    /// Remove um registro.
    /// </summary>
    Task DeleteAsync({{info.EntityName}} entity, CancellationToken ct = default);

    /// <summary>
    /// Verifica se existe um registro com o ID especificado.
    /// </summary>
    Task<bool> ExistsAsync({{existsParams}}, CancellationToken ct = default);
}
""";
    }

    /// <summary>
    /// Gera a Implementação do Repository.
    /// </summary>
    public static string GenerateImplementation(EntityInfo info)
    {
        var entityNs = $"{info.BaseNamespace}.Core.Entities";

        // ✅ v4.7: Usa helpers para PK composta
        var getByIdParams = info.PrimaryKeyParameterList;
        var findArgs = info.PrimaryKeyFindArgs;
        var linqFilter = info.PrimaryKeyLinqFilter;
        var logExpression = GenerateLogExpression(info, "entity");

        return $$"""
{{info.FileHeader}}
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using {{entityNs}};
using {{info.RepositoryInterfaceNamespace}};
using {{info.DbContextNamespace}};

namespace {{info.RepositoryImplNamespace}};

/// <summary>
/// Implementação do repositório de {{info.DisplayName}}.
/// </summary>
public sealed class {{info.EntityName}}Repository : I{{info.EntityName}}Repository
{
    private readonly {{info.DbContextName}} _context;
    private readonly ILogger<{{info.EntityName}}Repository> _logger;

    public {{info.EntityName}}Repository(
        {{info.DbContextName}} context,
        ILogger<{{info.EntityName}}Repository> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <inheritdoc/>
    public IQueryable<{{info.EntityName}}> Query()
    {
        
        return _context.Set<{{info.EntityName}}>();
    }

    /// <inheritdoc/>
    public async Task<{{info.EntityName}}?> GetByIdAsync({{getByIdParams}}, CancellationToken ct = default)
    {
        return await _context.Set<{{info.EntityName}}>()
            .FirstOrDefaultAsync(e => {{linqFilter}}, ct);
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<{{info.EntityName}}>> GetAllAsync(CancellationToken ct = default)
    {
        return await _context.Set<{{info.EntityName}}>()
            .AsNoTracking()
            .ToListAsync(ct);
    }

    /// <inheritdoc/>
    public async Task AddAsync({{info.EntityName}} entity, CancellationToken ct = default)
    {
        await _context.Set<{{info.EntityName}}>().AddAsync(entity, ct);
        await _context.SaveChangesAsync(ct);

        _logger.LogDebug("{{info.DisplayName}} adicionado: {Id}", {{logExpression}});
    }

    /// <inheritdoc/>
    public async Task UpdateAsync({{info.EntityName}} entity, CancellationToken ct = default)
    {
        // =====================================================================
        // ⭐ v4.8 FIX: NÃO usar EntityState.Modified em entidade já tracked.
        //
        // O fluxo correto é:
        // 1. Handler busca entidade via GetByIdAsync (tracked pelo DbContext)
        // 2. AutoMapper altera APENAS as propriedades do Request na entidade
        // 3. EF Core Change Tracker detecta automaticamente quais props mudaram
        // 4. SaveChanges gera UPDATE apenas nas colunas alteradas
        //
        // Problema do EntityState.Modified:
        // - Marca TODAS as propriedades como modificadas (incluindo PK, Id, TenantId)
        // - Gera SQL UPDATE com SET em TODAS as colunas
        // - Para PK composta: SQL Server não permite UPDATE na PK → DbUpdateException
        // - Para Id (Guid): pode sobrescrever com Guid.Empty se AutoMapper mapeou errado
        //
        // Se a entidade NÃO estiver tracked (cenário Detached), EF vai lançar
        // exceção no SaveChanges → comportamento correto que obriga buscar primeiro.
        // =====================================================================
        await _context.SaveChangesAsync(ct);

        _logger.LogDebug("{{info.DisplayName}} atualizado: {Id}", {{logExpression}});
    }

    /// <inheritdoc/>
    public async Task DeleteAsync({{info.EntityName}} entity, CancellationToken ct = default)
    {
        _context.Set<{{info.EntityName}}>().Remove(entity);
        await _context.SaveChangesAsync(ct);

        _logger.LogDebug("{{info.DisplayName}} removido: {Id}", {{logExpression}});
    }

    /// <inheritdoc/>
    public async Task<bool> ExistsAsync({{getByIdParams}}, CancellationToken ct = default)
    {
        return await _context.Set<{{info.EntityName}}>()
            .AnyAsync(e => {{linqFilter}}, ct);
    }
}
""";
    }

    /// <summary>
    /// Gera expressão de log para PK simples ou composta.
    /// Simples: entity.Id | Composta: $"{entity.CdSistema}|{entity.CdFuncao}"
    /// </summary>
    private static string GenerateLogExpression(EntityInfo info, string entityVar)
    {
        if (!info.HasCompositeKey)
            return $"{entityVar}.{info.PrimaryKeyProperty}";

        var interpolations = info.CompositeKeyProperties
            .Select(p => $"{{{entityVar}.{p}}}");
        return "$\"" + string.Join("|", interpolations) + "\"";
    }
}