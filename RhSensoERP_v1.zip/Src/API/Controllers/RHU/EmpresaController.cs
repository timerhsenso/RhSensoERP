using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RhSensoERP.Infrastructure.Persistence;
using RhSensoERP.Core.Shared;
using RhSensoERP.Core.Abstractions.Paging;
using RhSensoERP.Core.RHU.Entities;
using RhSensoERP.Core.RHU.DTOs;

namespace RhSensoERP.API.Controllers.RHU
{
    [ApiController]
    [Route("api/v1/rhu/[controller]")]
    [Produces("application/json")]
    public class EmpresaController : ControllerBase
    {
        private readonly AppDbContext _db;
        public EmpresaController(AppDbContext db) => _db = db;

        private static IOrderedQueryable<T> ApplySort<T>(IQueryable<T> q, string? sort)
        {
            if (string.IsNullOrWhiteSpace(sort)) return (IOrderedQueryable<T>)q;
            var desc = sort.StartsWith("-");
            var prop = desc ? sort.Substring(1) : sort;
            return desc ? q.OrderByDescending(e => EF.Property<object>(e, prop))
                        : q.OrderBy(e => EF.Property<object>(e, prop));
        }

        private static byte[] ToCsv<T>(IEnumerable<T> rows, string sep = ";")
        {
            var props = typeof(T).GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
            var lines = new List<string>();
            lines.Add(string.Join(sep, props.Select(p => Escape(p.Name, sep))));
            foreach (var r in rows)
                lines.Add(string.Join(sep, props.Select(p => Escape(p.GetValue(r), sep))));
            return System.Text.Encoding.UTF8.GetBytes(string.Join("\n", lines));
        }
        private static string Escape(object? v, string sep)
        {
            if (v is null) return string.Empty;
            var s = Convert.ToString(v) ?? string.Empty;
            if (s.Contains(sep) || s.Contains('\n') || s.Contains('\r') || s.Contains('"'))
                s = "\""+ s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        // LIST
        [HttpGet]
        public async Task<ActionResult<ApiResponse<PagedResult<EmpresaListItemDto>>>> List(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20,
            [FromQuery] string? sort = null, int? cdEmpresa = null, string? nome = null)
        {
            var q = _db.Set<Empresa>().AsNoTracking().AsQueryable();
            if (cdEmpresa.HasValue) q = q.Where(x => x.CdEmpresa == cdEmpresa.Value);
            if (!string.IsNullOrWhiteSpace(nome)) q = q.Where(x => (x.NmEmpresa ?? "").Contains(nome) || (x.NmFantasia ?? "").Contains(nome));
            var ordered = ApplySort(q, sort);
            var total = await ordered.CountAsync();
            var items = await ordered
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new EmpresaListItemDto { CdEmpresa = x.CdEmpresa, NmEmpresa = x.NmEmpresa, NmFantasia = x.NmFantasia })
                .ToListAsync();
            var resp = new PagedResult<EmpresaListItemDto> { Items = items, Page = page, PageSize = pageSize, TotalCount = total };
            return Ok(ApiResponse<PagedResult<EmpresaListItemDto>>.Ok(resp));
        }

        // EXPORT
        [HttpPost("export")]
        public async Task<IActionResult> Export([FromQuery] string? sort = null, int? cdEmpresa = null, string? nome = null)
        {
            var q = _db.Set<Empresa>().AsNoTracking().AsQueryable();
            if (cdEmpresa.HasValue) q = q.Where(x => x.CdEmpresa == cdEmpresa.Value);
            if (!string.IsNullOrWhiteSpace(nome)) q = q.Where(x => (x.NmEmpresa ?? "").Contains(nome) || (x.NmFantasia ?? "").Contains(nome));
            var ordered = ApplySort(q, sort);
            var rows = await ordered.Select(x => new EmpresaListItemDto { CdEmpresa = x.CdEmpresa, NmEmpresa = x.NmEmpresa, NmFantasia = x.NmFantasia }).ToListAsync();
            var bytes = ToCsv(rows);
            return File(bytes, "text/csv", "temp1_export.csv");
        }

        // GET BY KEY
        [HttpGet("{cdEmpresa:int}")]
        public async Task<ActionResult<ApiResponse<Empresa>>> Get(int cdEmpresa)
        {
            var entity = await _db.Set<Empresa>().AsNoTracking().FirstOrDefaultAsync(x => x.CdEmpresa == cdEmpresa);
            if (entity == null) return NotFound(ApiResponse<Empresa>.Fail("Registro não encontrado."));
            return Ok(ApiResponse<Empresa>.Ok(entity));
        }

        // CREATE
        [HttpPost]
        public async Task<ActionResult<ApiResponse<Empresa>>> Create([FromBody] Empresa model)
        {
            _db.Set<Empresa>().Add(model);
            await _db.SaveChangesAsync();
            return Ok(ApiResponse<Empresa>.Ok(model, "Criado com sucesso."));
        }

        // UPDATE
        [HttpPut("{cdEmpresa:int}")]
        public async Task<ActionResult<ApiResponse<object>>> Update(int cdEmpresa, [FromBody] Empresa model)
        {
            var exists = await _db.Set<Empresa>().AnyAsync(x => x.CdEmpresa == cdEmpresa);
            if (!exists) return NotFound(ApiResponse<object>.Fail("Registro não encontrado para atualização."));
            _db.Entry(model).State = EntityState.Modified;
            await _db.SaveChangesAsync();
            return Ok(ApiResponse<object>.Ok(new { }, "Atualizado com sucesso."));
        }

        // DELETE
        [HttpDelete("{cdEmpresa:int}")]
        public async Task<ActionResult<ApiResponse<object>>> Delete(int cdEmpresa)
        {
            var e = await _db.Set<Empresa>().FirstOrDefaultAsync(x => x.CdEmpresa == cdEmpresa);
            if (e == null) return NotFound(ApiResponse<object>.Fail("Registro não encontrado para exclusão."));
            _db.Remove(e);
            await _db.SaveChangesAsync();
            return Ok(ApiResponse<object>.Ok(new { }, "Excluído com sucesso."));
        }

        public class EmpresaKeyDto
        {
            public int CdEmpresa { get; set; }
        }

        
[HttpPost("bulk-delete")]
public async Task<ActionResult<ApiResponse<object>>> BulkDelete([FromBody] IEnumerable<EmpresaKeyDto> keys)
{
    var set = _db.Set<Empresa>();
    foreach (var k in keys)
    {
        var e = await set.FirstOrDefaultAsync(x.CdEmpresa == k.CdEmpresa);
        if (e != null) _db.Remove(e);
    }
    await _db.SaveChangesAsync();
    return Ok(ApiResponse<object>.Ok(new { }, "Registros excluídos."));
}

            await _db.SaveChangesAsync();
            return Ok(ApiResponse<object>.Ok(new { }, "Registros excluídos."));
        }

    }
}
