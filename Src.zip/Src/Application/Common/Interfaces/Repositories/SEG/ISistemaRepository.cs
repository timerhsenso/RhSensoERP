// Ajuste o alias abaixo conforme ONDE está sua entidade:
// Se sua entidade estiver em RhSensoERP.Core.Security.Entities, troque a linha do alias.
//using SistemaEntity = RhSensoERP.Core.SEG.Entities.Sistema;
using SistemaEntity = RhSensoERP.Core.Security.Entities;    


namespace RhSensoERP.Application.Common.Interfaces.Repositories.SEG
{
    public interface ISistemaRepository
    {
        Task<List<SistemaEntity>> GetAllAsync(CancellationToken ct = default);
        Task<SistemaEntity?> GetByIdAsync(string cdSistema, CancellationToken ct = default);
        Task<bool> ExistsAsync(string cdSistema, CancellationToken ct = default);
        Task AddAsync(SistemaEntity entity, CancellationToken ct = default);
        Task UpdateAsync(SistemaEntity entity, CancellationToken ct = default);
        Task<bool> DeleteAsync(string cdSistema, CancellationToken ct = default);
        Task<int> SaveChangesAsync(CancellationToken ct = default);
    }
}
